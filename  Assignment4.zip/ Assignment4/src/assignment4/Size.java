package assignment4;

public enum Size {
    XS, S, M, L, XL, XXL, XXXL
    
}