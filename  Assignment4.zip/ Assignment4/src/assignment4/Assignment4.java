package assignment4;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Assignment4 {

    public static void main(String[] args) {
        List<TShirt> tShirts = new ArrayList<TShirt>();
        Sort sort;

        long startTime = System.currentTimeMillis();
        tShirts = generateTShirts(4, 1);
        sort = new Sort(tShirts);
        long endTime = System.currentTimeMillis();
        System.out.println("Generation of 4 TShirts (type 1) on: "
                + (endTime - startTime));

//        System.out.println("UnSorted Array");
//        printTShirts(tShirts);
       System.out.println("Sorted Array");

        System.out.println("Quick Sort - asc");
        printTShirtsBySize(sort.sortBySize(0, 0));
        System.out.println("");
        System.out.println("Bubble Sort - desc");
        printTShirtsBySize(sort.sortBySize(1, 1));
        System.out.println("");
        System.out.println("Quick Sort - asc");
        printTShirtsByColor(sort.sortByColor(0, 0));
        System.out.println("");
        System.out.println("Bubble - desc");
        printTShirtsByColor(sort.sortByColor(1, 1)); 
        System.out.println("");
        System.out.println("Quick Sort - asc");
        printTShirtsByFabric(sort.sortByFabric(0, 0));
        System.out.println("");
        System.out.println("Bubble Sort - desc");
        printTShirtsByFabric(sort.sortByFabric(1, 1)); 
   

    }

    public static List<TShirt> generateTShirts(int count, int type) {
        List<TShirt> tShirts = new ArrayList<TShirt>();
        for (int i = 0; i < count; i++) {
            TShirt e = new TShirt();
            e.setName(randomName(type));
            e.setColor(randomColor());
            e.setSize(randomSize());
            e.setFabric(randomFabric());
            tShirts.add(e);
        }
        return tShirts;
    }

    /*
    type = 0, String concatenation
    type = 1, StringBuilder
     */
    public static String randomName(int type) {
        char chars[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
        Random random = new Random();
        String s = "";
        switch (type) {
            case 0:
                for (int i = 0; i < 12; i++) {
                    s += chars[random.nextInt(26)];
                }
                break;
            case 1:
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < 12; i++) {
                    sb.append(chars[random.nextInt(26)]);
                }
                s = sb.toString();
                break;
        }
        return s;
    }

    public static Color randomColor() {
        Random random = new Random();
        return Color.values()[random.nextInt(Color.values().length)];
    }

    public static Size randomSize() {
        Random random = new Random();
        return Size.values()[random.nextInt(Size.values().length)];
    }

    public static Fabric randomFabric() {
        Random random = new Random();
        return Fabric.values()[random.nextInt(Fabric.values().length)];
    }

    public static void printTShirtsBySize(List<TShirt> tShirts) {
        for (TShirt e : tShirts) {
            System.out.println(e.getName() + " " + e.getSize());
        }
    }

    public static void printTShirtsByColor(List<TShirt> tShirts) {
        for (TShirt e : tShirts) {
            System.out.println(e.getName() + " " + e.getColor());
        }
    }

    public static void printTShirtsByFabric(List<TShirt> tShirts) {
        for (TShirt e : tShirts) {
            System.out.println(e.getName() + " " + e.getFabric());
        }
    }
}
