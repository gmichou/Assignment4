package assignment4;

import java.util.ArrayList;
import java.util.List;

public class Sort {

    private List<TShirt> tShirts;

    Sort(List<TShirt> shirts) {
        this.tShirts = new ArrayList<TShirt>(shirts);
    }

    public List<TShirt> gettShirts() {
        return tShirts;
    }

    public void settShirts(List<TShirt> tShirts) {
        this.tShirts = tShirts;
    }

    public List<TShirt> sortBySize(int sortMethod, int sortOrder) {
        List<TShirt> shirts = new ArrayList<TShirt>(this.tShirts);
        switch (sortMethod) {
            case 0:
                shirts = quickSortBySize(0, shirts.size() - 1, sortOrder);
                break;
            case 1:
                shirts = bubbleSortBySize(sortOrder);
                break;
        }
        return shirts;
    }

    public List<TShirt> sortByColor(int sortMethod, int sortOrder) {
        List<TShirt> shirts = new ArrayList<TShirt>(this.tShirts);
        switch (sortMethod) {
            case 0:
                shirts = quickSortByColor(0, shirts.size() - 1, sortOrder);
                break;
            case 1:
                shirts = bubbleSortByColor(sortOrder);
                break;
           
        }

        return shirts;

    }

    /*
    sortMethod = 0, Quick Sort
    sortMethod = 1, Bubble Sort
    sortMethod = 2, Bucket Sort
    sortOrder = 0, ASC
    sortOrder = 1, DESC
     */
    public List<TShirt> sortByFabric(int sortMethod, int sortOrder) {
        List<TShirt> shirts = new ArrayList<TShirt>(this.tShirts);
        switch (sortMethod) {
            case 0:
                 shirts = quickSortByFabric(0, shirts.size() - 1, sortOrder);
                break;
            case 1:
                 shirts = bubbleSortByFabric(sortOrder);
                break;
        }

        return shirts;

    }

    private List<TShirt> bubbleSortBySize(int type) {//bubbleSortBySize
        int n = tShirts.size();
        List<TShirt> tempShirts = tShirts;
        switch (type) {
            case 0://asc
                for (int i = 0; i < n - 1; i++) {
                    for (int j = 0; j < n - i - 1; j++) {
                        if (tempShirts.get(j).getSize().ordinal() > tempShirts.get(j + 1).getSize().ordinal()) {
                            TShirt temp = tempShirts.get(j);
                            tempShirts.set(j, tempShirts.get(j + 1));
                            tempShirts.set(j + 1, temp);
                        }
                    }
                }
                break;
            case 1://desc
                for (int i = 0; i < n - 1; i++) {
                    for (int j = 0; j < n - i - 1; j++) {
                        if (tempShirts.get(j).getSize().ordinal() < tempShirts.get(j + 1).getSize().ordinal()) {
                            TShirt temp = tempShirts.get(j);
                            tempShirts.set(j, tempShirts.get(j + 1));
                            tempShirts.set(j + 1, temp);
                        }
                    }
                }
                break;
        }

        return tempShirts;
    }

    private List<TShirt> bubbleSortByColor(int type) {//bubbleSortByColor
        int n = tShirts.size();
        List<TShirt> tempShirts = tShirts;
        switch (type) {
            case 0://asc
                for (int i = 0; i < n - 1; i++) {
                    for (int j = 0; j < n - i - 1; j++) {
                        if (tempShirts.get(j).getColor().ordinal() > tempShirts.get(j + 1).getColor().ordinal()) {
                            TShirt temp = tempShirts.get(j);
                            tempShirts.set(j, tempShirts.get(j + 1));
                            tempShirts.set(j + 1, temp);
                        }
                    }
                }
                break;
            case 1://desc
                for (int i = 0; i < n - 1; i++) {
                    for (int j = 0; j < n - i - 1; j++) {
                        if (tempShirts.get(j).getColor().ordinal() < tempShirts.get(j + 1).getColor().ordinal()) {
                            TShirt temp = tempShirts.get(j);
                            tempShirts.set(j, tempShirts.get(j + 1));
                            tempShirts.set(j + 1, temp);
                        }
                    }
                }
                break;
        }

        return tempShirts;
    }
 private List<TShirt> bubbleSortByFabric(int type) {//bubbleSortByFabric
        int n = tShirts.size();
        List<TShirt> tempShirts = tShirts;
        switch (type) {
            case 0://asc
                for (int i = 0; i < n - 1; i++) {
                    for (int j = 0; j < n - i - 1; j++) {
                        if (tempShirts.get(j).getFabric().ordinal() > tempShirts.get(j + 1).getFabric().ordinal()) {
                            TShirt temp = tempShirts.get(j);
                            tempShirts.set(j, tempShirts.get(j + 1));
                            tempShirts.set(j + 1, temp);
                        }
                    }
                }
                break;
            case 1://desc
                for (int i = 0; i < n - 1; i++) {
                    for (int j = 0; j < n - i - 1; j++) {
                        if (tempShirts.get(j).getFabric().ordinal() < tempShirts.get(j + 1).getFabric().ordinal()) {
                            TShirt temp = tempShirts.get(j);
                            tempShirts.set(j, tempShirts.get(j + 1));
                            tempShirts.set(j + 1, temp);
                        }
                    }
                }
                break;
        }

        return tempShirts;
    }
    private int quickPartition(List<TShirt> arr, int low, int high, int sortOrder) {
        TShirt pivot = arr.get(high);
        int i = (low - 1); // index of smaller element 
        for (int j = low; j < high; j++) {
            if (sortOrder == 0) {//asc
                // If current element is smaller than the pivot 
                if (arr.get(j).getSize().ordinal() < pivot.getSize().ordinal()) {
                    i++;

                    // swap arr[i] and arr[j] 
                    TShirt temp = arr.get(i);
                    arr.set(i, arr.get(j));
                    arr.set(j, temp);
                }
            } else {//desc
                // If current element is smaller than the pivot 
                if (arr.get(j).getSize().ordinal() > pivot.getSize().ordinal()) {
                    i++;

                    // swap arr[i] and arr[j] 
                    TShirt temp = arr.get(i);
                    arr.set(i, arr.get(j));
                    arr.set(j, temp);
                }
            }
        }

        // swap arr[i+1] and arr[high] (or pivot) 
        TShirt temp = arr.get(i + 1);
        arr.set(i + 1, arr.get(high));
        arr.set(high, temp);
        return i + 1;
    }

    private int quickPartitionC(List<TShirt> arr, int low, int high, int sortOrder) {
        TShirt pivot = arr.get(high);
        int i = (low - 1); // index of smaller element 
        for (int j = low; j < high; j++) {
            if (sortOrder == 0) {//asc
                // If current element is smaller than the pivot 
                if (arr.get(j).getColor().ordinal() < pivot.getColor().ordinal()) {
                    i++;

                    // swap arr[i] and arr[j] 
                    TShirt temp = arr.get(i);
                    arr.set(i, arr.get(j));
                    arr.set(j, temp);
                }
            } else {//desc
                // If current element is smaller than the pivot 
                if (arr.get(j).getColor().ordinal() > pivot.getColor().ordinal()) {
                    i++;

                    // swap arr[i] and arr[j] 
                    TShirt temp = arr.get(i);
                    arr.set(i, arr.get(j));
                    arr.set(j, temp);
                }
            }
        }

        // swap arr[i+1] and arr[high] (or pivot) 
        TShirt temp = arr.get(i + 1);
        arr.set(i + 1, arr.get(high));
        arr.set(high, temp);
        return i + 1;
    }

    private int quickPartitionF(List<TShirt> arr, int low, int high, int sortOrder) {
        TShirt pivot = arr.get(high);
        int i = (low - 1); // index of smaller element 
        for (int j = low; j < high; j++) {
            if (sortOrder == 0) {//asc
                // If current element is smaller than the pivot 
                if (arr.get(j).getFabric().ordinal() < pivot.getFabric().ordinal()) {
                    i++;

                    // swap arr[i] and arr[j] 
                    TShirt temp = arr.get(i);
                    arr.set(i, arr.get(j));
                    arr.set(j, temp);
                }
            } else {//desc
                // If current element is smaller than the pivot 
                if (arr.get(j).getFabric().ordinal() > pivot.getFabric().ordinal()) {
                    i++;

                    // swap arr[i] and arr[j] 
                    TShirt temp = arr.get(i);
                    arr.set(i, arr.get(j));
                    arr.set(j, temp);
                }
            }
        }

        // swap arr[i+1] and arr[high] (or pivot) 
        TShirt temp = arr.get(i + 1);
        arr.set(i + 1, arr.get(high));
        arr.set(high, temp);
        return i + 1;
    }

    public List<TShirt> quickSortBySize(int low, int high, int sortOrder) //quickSortBySize
    {
        List<TShirt> arr = this.tShirts;
        List<TShirt> arr2 = arr;
        if (low < high) {
            /* pi is partitioning index, arr[pi] is  
              now at right place */
            int pi = quickPartition(arr2, low, high, sortOrder);

            // Recursively sort elements before 
            // partition and after partition 
            quickSortBySize(low, pi - 1, sortOrder);
            quickSortBySize(pi + 1, high, sortOrder);
        }
        return arr2;
    }

    public List<TShirt> quickSortByColor(int low, int high, int sortOrder) //quickSortByColor
    {
        List<TShirt> arr = this.tShirts;
        List<TShirt> arr2 = arr;
        if (low < high) {
            /* pi is partitioning index, arr[pi] is  
              now at right place */
            int pi = quickPartitionC(arr2, low, high, sortOrder);

            // Recursively sort elements before 
            // partition and after partition 
            quickSortByColor(low, pi - 1, sortOrder);
            quickSortByColor(pi + 1, high, sortOrder);
        }
        return arr2;
    }
     public List<TShirt> quickSortByFabric(int low, int high, int sortOrder) //quickSortByFabric
    {
        List<TShirt> arr = this.tShirts;
        List<TShirt> arr2 = arr;
        if (low < high) {
            /* pi is partitioning index, arr[pi] is  
              now at right place */
            int pi = quickPartitionF(arr2, low, high, sortOrder);

            // Recursively sort elements before 
            // partition and after partition 
            quickSortByFabric(low, pi - 1, sortOrder);
            quickSortByFabric(pi + 1, high, sortOrder);
        }
        return arr2;
    }

}
